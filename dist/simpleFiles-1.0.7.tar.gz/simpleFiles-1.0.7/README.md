# Better file system
it makes writing to files easy

#how to use
import b
####create a file######
tfile = 
